<?php
if (!isset($_SESSION)) {
    session_start();
}

if (isset($_SESSION['LoggedInEmail'])) {
    header("Location: tasks.php");
    exit;
} else {
    header("Location: login.php");
    exit;
}
?>
