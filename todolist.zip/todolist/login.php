<?php
if (!isset($_SESSION)) {
    session_start();
}
if (isset($_SESSION['LoggedInEmail'])) {
    header("Location: tasks.php");
    exit;
}

include_once("connections/connection.php");
$db_connection = connection();

$loginMessage = "";
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sha1Encrypted = sha1($password);
    $fetchedRows = -1;

    $sql = "SELECT * FROM `app_users` WHERE email='$email' AND password='$sha1Encrypted'";
    $result = $db_connection->query($sql) or die($db_connection->error);
    $fetchedRows = $result->num_rows;

    if ($fetchedRows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION['LoggedInEmail'] = $user['email'];
        header("Location: tasks.php");
        exit;
    } else {
        $loginMessage = "Invalid email or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To Do List App</title>
    <style>
        /* Add your custom CSS styles here */
    </style>
</head>

<body>
    <h1>To Do List App</h1>
    <h2>Login</h2>

    <form action="" method="post">
        <label for="email">Email</label>
        <input type="email" name="email" id="email" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <input type="submit" name="login" id="login" value="Login">
    </form>

    <div id="login-message"><?php echo $loginMessage; ?></div>

    <script src="js/login.js"></script>
</body>

</html>
